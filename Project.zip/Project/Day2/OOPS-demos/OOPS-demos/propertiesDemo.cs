﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OOPS_demos
{
    class Person
    {
        //prop - new style of declaring properties - preferred for just declaration
         
        public int ID { get; set; }

        //propfull - old style of declaring properties - preferred for write business logic like validation

        private string myVar;

        public string Name
        {
            get { return myVar; }
            set { myVar = value; }
        }
        
    }
}

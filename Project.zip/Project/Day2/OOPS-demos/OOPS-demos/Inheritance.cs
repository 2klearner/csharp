﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OOPS_demos
{
    class parent
    {
        public parent()
        {
            Console.WriteLine("parent class constructor called");
        }

        public double GetRandom()
        {
            Random r = new Random();
            return r.NextDouble();
        }
    }

 


    // class Child: parentA,ParentB //multiple inheritance
    //{
    //    this is not supported in C#
    //    achieve Multiple inheritance by using interfaces

    //}


    class Child : parent //single inheritance
    {
        public Child()
        {
            Console.WriteLine("constructor of child class called");
        }

    }


    class GrandChild : Child //multilevel inheritance
    {
        public GrandChild()
        {
            Console.WriteLine("constructor of grandchild class called");
        }

    }

}
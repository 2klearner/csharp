﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OOPS_demos
{
    public class Student
    {
        // Store the state of the student

        //propfull

        private int id;

        public int ID
        {
            get { return id; }
            set { id = value; }
        }

        private string myVar;

        public string Name
        {
            get { return myVar; }
            set { myVar = value; }
        }

        public void displayDetails() 
        {
            Console.WriteLine("id is " +this.id);
            Console.WriteLine("name is " +this.myVar);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OOPS_demos
{
    interface Isecure
    {
        string Encrypt(string pwd);
    }

    interface Isecure2
    {
        string Encrypt(string pwd);
    }

    class EncryptClass : Isecure, Isecure2
    {
        //How do you indicate which methods belongs to which
        // when ur prefixing with interface name
        string Isecure.Encrypt(string pwd) 
        {
            return "Isecure- encrypt called";
                    
        }

        string Isecure2.Encrypt(string pwd)
        {
            return "Isecure2- encrypt called";
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OOPS_demos
{
    public interface IMath
    {
        double log(double d);
        double sin(double d);
        double cos(double d);
        double Tan(double d);
    }

    public interface IMath2
    {
        double Pow(double a, double b);
        double Sqrt(double d);
       
    }


    // we have an option called implement interface we can use
    class Calculator: IMath, IMath2
    {


        public double log(double d)
        {
            return Math.Log(d);
        }

        public double sin(double d)
        {
            return Math.Sin(d);
        }

        public double cos(double d)
        {
            return Math.Cos(d);
        }

        public double Tan(double d)
        {
            return Math.Tan(d); 
        }

        public double Pow(double a, double b)
        {
            return Math.Pow(a, b);
        }

        public double Sqrt(double d)
        {
            return Math.Sqrt(d); 
        }
    }
}

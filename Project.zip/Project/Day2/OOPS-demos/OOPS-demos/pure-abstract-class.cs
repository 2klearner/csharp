﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OOPS_demos
{
    public abstract class FileWrite
    {
        //Pure Abstract class
        public abstract void Write2TXT();
        public abstract void Write2XT();
        public abstract void Write2CSV();
        public abstract void Write2JSON();
    }

    public class MyFile : FileWrite
    {

        public override void Write2TXT()
        {
            Console.WriteLine();
        }

        public override void Write2XT()
        {
            
        }

        public override void Write2CSV()
        {
            
        }

        public override void Write2JSON()
        {
            
        }
    }

}

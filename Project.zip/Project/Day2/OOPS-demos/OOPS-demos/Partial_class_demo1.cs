﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OOPS_demos
{
    public partial class DB
    {
        public void Method1() 
        {
            Console.WriteLine("Method1 called");
        } 

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OOPS_demos
{
    //classname is prefixed with static

    public static class pure_static_classes
    {
        public static pure_static_classes()
        {
            Console.WriteLine("static constructor");
        }
        public static void M1()
        {
            Console.WriteLine("static method called");
        }

        public static void M2()
        {
            Console.WriteLine("static method called");
        }
    }
}

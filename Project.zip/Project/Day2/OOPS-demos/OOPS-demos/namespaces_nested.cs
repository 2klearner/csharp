﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OOPS_demos
{
    namespace Outer
    {
        namespace Inner
        {
            namespace InnerMost
            {
                public class MyClass
                {
                    public void Method1()
                    {

                        Console.WriteLine("Method1 called");
                    }
                }
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OOPS_demos
{
    public class MethodOverloading
    {
        // Functional Overloading

        //public int add(int a, int b) 
        //{
        //    return a + b;
        //}

        //public int add(int a, int b, int c)
        //{
        //    return a + b + c;
        //}

        //public string add(string str, string str2) 
        //{
        //    return String.Concat(str, str2);
        //}


        public int add(int a, int b)
        {
            return a + b;
        }

        public double add(double a, double b)
        {
            return a + b;
        }

        //everything derived from object so u cannot do this
        public object add(object a, object b)
        {
            return "object";
        }

    }
}

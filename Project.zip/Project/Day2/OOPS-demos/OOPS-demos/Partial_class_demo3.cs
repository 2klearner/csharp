﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OOPS_demos
{
    public partial class DB
    {
        public void Method3()
        {
            Console.WriteLine("Method3 called");
        }
    }
}

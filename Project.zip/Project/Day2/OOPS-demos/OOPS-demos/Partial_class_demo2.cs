﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OOPS_demos
{
    public partial class DB 
    {
        public void Method2()
        {
            Console.WriteLine("Method2 called");
        } 
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OOPS_demos
{
    public abstract class DBConnect 
    {
        public abstract void ConnectToDB();

        public void GetData() 
        {
            //write the logic of "select"
        
        }
        public void InsertData()
        {
            //write the logic of "insert"

        }

        public void UpdateData()
        {
            //write the logic of "update"

        }
        public void DeleteData()
        {
            //write the logic of "delete"

        }
    }

    public class Connect2Oracle : DBConnect
    {

        public override void ConnectToDB()
        {
            Console.WriteLine("Connected to oracle db");
 
        }
    }   
}

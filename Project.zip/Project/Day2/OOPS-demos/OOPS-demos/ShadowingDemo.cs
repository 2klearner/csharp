﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OOPS_demos
{
    class Shape
    {
        public void Draw() 
        {
            Console.WriteLine("draw of shape class called");
                    
        }
    }

    class Rectangle: Shape
    {
        public new void Draw()   
        {
            Console.WriteLine("draw of rectangle class called");
        }


    }
}

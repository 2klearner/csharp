﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OOPS_demos
{
    class ConstructorDemo
    {
        private int x;
        private int y;

        public ConstructorDemo()
        {
            Console.WriteLine("default constructor");
        }

        public ConstructorDemo(string str)
        {
            Console.WriteLine("parameterized constructor");
        }

        public ConstructorDemo(string str, int i)
        {
            Console.WriteLine("parameterized constructor with 2 parameters");
        }

        public ConstructorDemo(int x, int y)
        {
            this.x = x;
            this.y = y;

            Console.WriteLine("the value of x and y is : "+x+ " "+y);
        }
    }
}

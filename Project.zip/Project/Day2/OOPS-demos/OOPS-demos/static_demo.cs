﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OOPS_demos
{
    public class static_demo
    {
        public static void M1()
        {
            Console.WriteLine("static method called");
        }

        public void M2()
        {
            Console.WriteLine("non static/instance method called");
        }
    }
}

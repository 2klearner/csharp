﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OOPS_demos
{
    //Method overriding in Inheritance

    class Car  //base class , it has some specs
    {
        public virtual void Fuel() // mark my method as virtual
        {
            Console.WriteLine("it runs on fuel");
        }
        
    }

    class Nano:Car
    {
         public override void Fuel() // mark as override
        {
            base.Fuel();
            Console.WriteLine("it runs on petrol");
        }
    }

    sealed class Ford:Car
    {
          public override void Fuel()
        {

            Console.WriteLine("it runs on diesel");
        }
    }
}

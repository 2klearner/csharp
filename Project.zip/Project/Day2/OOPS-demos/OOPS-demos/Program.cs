﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using OOPS_demos.Outer.Inner.InnerMost;

using custom=OOPS_demos.Outer.Inner.InnerMost; // aliases w.r.t namespaces
namespace OOPS_demos
{
    class Program
    {
        static void Main(string[] args)
        {
            //Outer.Inner.InnerMost.MyClass mc=new Outer.Inner.InnerMost.MyClass();
            //mc.Method1();

            //MyClass obj1 = new MyClass();
            //MyClass obj2 = new MyClass();
            //MyClass obj3 = new MyClass();
            ////obj1.Method1();

            ////determines whether specified objects instances are the same instance
            //Console.WriteLine(object.ReferenceEquals(obj1,obj2));
            
            //custom.MyClass obj = new custom.MyClass();
            //obj.Method1();
            //ConstructorDemo cd = new ConstructorDemo();
            //ConstructorDemo cd1 = new ConstructorDemo("abi");
            //ConstructorDemo cd2 = new ConstructorDemo("abi",2);
            //ConstructorDemo cd3 = new ConstructorDemo(10, 18);

            //single inheritance
            //Child c = new Child();
            //c.GetRandom();


            // Multilevel inheritance

            //GrandChild gc = new GrandChild();

            //Nano n = new Nano();

            //downcasting
            //Car c = new Ford();
            //c.Fuel();

            //upcasting not possible
            //Ford f = new Car();

            //shadowing
            //Shape s = new Rectangle();
            //s.Draw();

            //MethodOverloading md = new MethodOverloading();
            //Console.WriteLine(md.add(1,"abi")); 

            //Student obj = new Student();
            //obj.ID = 123;
            //obj.Name = "C#";

            //obj.displayDetails();

            //Interface using class
            //Calculator c = new Calculator();
            //Console.WriteLine("log is "+c.log(10));
            //Console.WriteLine("sin is " + c.sin(10));
            //Console.WriteLine("cos is " + c.cos(10));
            //Console.WriteLine("tan is " + c.Tan(10));
            //Console.WriteLine("Power is " + c.Pow(10,2));


            //Interface cannot be instantiated
            //IMath i = new IMath();

            //EncryptClass ec = new EncryptClass();

            //by doing downcasting we can call same method name in different interfaces
            //Isecure is1 = new EncryptClass();
            //Console.WriteLine(is1.Encrypt("abi"));

            //Isecure2 is2 = new EncryptClass();
            //Console.WriteLine(is2.Encrypt("sahi"));

            ////Abstract class cannot be instantiated
            ////DBConnect db = new DBConnect();

            //Connect2Oracle ora = new Connect2Oracle();
            //ora.ConnectToDB();

            //partial classes
            //DB d = new DB();
            //d.Method2();

            //calling a static method 
            static_demo.M1();

            //calling a instance/ non static method
            static_demo sd = new static_demo();
            sd.M2();

            pure_static_classes.M1();
            pure_static_classes.M2();


        }
    }
}

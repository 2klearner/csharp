﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HelloWorld
{

    public class Sample
    {
        public double getRandom()
        {
            Random r = new Random();
            return r.NextDouble();

        }

        public string getCurrentDateTime()
        {
            return DateTime.Now.ToString();
        }
    }
}

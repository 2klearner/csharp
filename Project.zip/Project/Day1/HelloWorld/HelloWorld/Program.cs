﻿using System; //pre defined namespace
using System.Collections.Generic;
using System.Linq;
using System.Text;
using HelloWorld;

namespace HelloWorld //user defined namespace
{
    class Program
    {
        static void Main(string[] args) //entry point of appln
        {
            Console.WriteLine("Hello World!");

            //int x = 10;
            //int y = 20;

            //string str = "c#";
            //int length = 5;

            //var z = 55; // decision of DT is left to compiler ( done at compile time)
            //dynamic d = 44; // decision of DT is left to compiler ( done at run time)  
            
            ////since it is base class, you can assign any dt to object
            
            //object obj2 = "abishek";
            //object obj3 = false;

            //if (true)
            //{

            //    for (int i = 0; i < length; i++)
            //    {
                    
            //    }
            //}

            //else
            //{
            //    do
            //    {
                    
            //    } while (true);
            //}
                     
            
            // ctrl+K+c ==> comment
            // ctrl+K+u ==> uncomment


            //Console.WriteLine();

            //Sample obj = new Sample();
            //var str1=obj.getCurrentDateTime();
            //Console.WriteLine(str1);

            //var d=obj.getRandom();
            //Console.WriteLine(d);
        }
    }
}

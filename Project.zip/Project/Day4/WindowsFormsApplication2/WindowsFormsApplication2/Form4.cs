﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[] a = new int[5]; //single dimensional array
            a[0] = 10;
            a[1] = 18;
            a[2] = 13;
            a[3] = 6;
            a[4] = 21;

            // other way of initializing array

            //int[] array = new int[5];
            //int[] array1 = new int[] {10,3,6,13,18};

            

            foreach (var item in a)
            {
                comboBox1.Items.Add(item);
            }

        }
    }
}

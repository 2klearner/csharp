﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MyLibrary;

namespace Call_DLL
{
    class Program
    {
        static void Main(string[] args)
        {
            MyClass obj = new MyClass();
            //int a=obj.add(10, 3);

            Console.WriteLine("enter first no");
            int a = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("enter second no");
            int b = Convert.ToInt32(Console.ReadLine());

            int result=obj.add(a,b);

            Console.WriteLine("Add of two numbers is: " +result);
        }
    }
}

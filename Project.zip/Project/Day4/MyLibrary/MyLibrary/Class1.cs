﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MyLibrary
{
    public class MyClass
    {
        public int add(int a, int b) 
        {
            return a + b;
        }

        public int sub(int a, int b)
        {
            return a - b;
        }
    }
}

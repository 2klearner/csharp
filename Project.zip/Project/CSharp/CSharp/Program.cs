﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CSharp
{
    class Program
    {
        static void Main(string[] args)
        {
            //Basic Hello World
            string message = "Hello C#";
            Console.WriteLine(message);
        }
    }
}

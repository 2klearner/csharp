﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TypeCasting
{
    [Flags]
    public enum Days
    {
        None      = 0,  // 0
        Monday    = 1,  // 1
        Tuesday   = 2,  // 2
        Wednesday = 4,  // 4
        Thursday  = 8,  // 8
        Friday    = 16,  // 16
        Saturday  = 32,  // 32
        Sunday    = 64,  // 64
        Weekend   = Saturday | Sunday
    }

    enum Season
    {
        Spring,
        Summer,
        Autumn,
        Winter
    }

    public class EnumExample
    {
        public static void Method1()
        {
            Days meetingDays = Days.Monday | Days.Wednesday | Days.Friday;
            Console.WriteLine(meetingDays);
        }

    }
}

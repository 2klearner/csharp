﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TypeCasting
{
    class Program
    {
        static void Main(string[] args)
        {
            int x = 10;

            double d = x; // implicit type casting

            int y = Convert.ToInt32(d);  //explicit typecasting
            //int y1 = (int)d; 

            // everything is derived from object DT
            object obj = x;    //boxing     

            int z = (int)obj; //unboxing
            int z1 = Convert.ToInt32(obj);

            //Enum
            EnumExample.Method1();

            Console.WriteLine(Season.Summer);

            //const

            Console.WriteLine("{0}  {1}  {2}", constant_demo.value1, constant_demo.value2, constant_demo.value3);
        }
    }
}

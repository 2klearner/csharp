﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TypeCasting
{
    class readonly_demo
    {
        readonly int i;

        public readonly_demo()
        {
            i = 11;
            Console.WriteLine(i);
        }
    }
}

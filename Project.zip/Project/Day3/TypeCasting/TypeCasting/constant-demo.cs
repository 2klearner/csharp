﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TypeCasting
{
    enum MyJob 
    {
        consultant
    }

    class constant_demo
    {
        public const int value1 = 23;
        public const string value2 = "sahi";
        public const MyJob value3 = MyJob.consultant;

    
    }
}
